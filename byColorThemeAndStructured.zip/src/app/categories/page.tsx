import Link from 'next/link';
import { dummyCategories } from '@/lib/data/dummy';

export default function CategoriesPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">All Categories</h1>
        <p className="text-gray-600 mt-1">Browse hardware & construction products by category</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {dummyCategories.map((cat) => (
          <Link
            key={cat.id}
            href={`/products?category=${cat.slug}`}
            className="group bg-white rounded-xl border border-gray-200 p-6 hover:border-[#2563eb] hover:shadow-lg transition-all"
          >
            <div className="w-16 h-16 rounded-xl bg-[#eff6ff] flex items-center justify-center text-3xl mb-4 group-hover:bg-[#dbeafe]">
              🔧
            </div>
            <h2 className="text-xl font-semibold text-gray-900 group-hover:text-[#2563eb]">
              {cat.name}
            </h2>
            {cat.description && (
              <p className="text-gray-600 mt-2 text-sm">{cat.description}</p>
            )}
            <p className="text-[#2563eb] font-medium mt-2">{cat.productCount} products →</p>
            {cat.subcategories && cat.subcategories.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {cat.subcategories.map((sub) => (
                  <span
                    key={sub.id}
                    className="text-xs px-2 py-1 bg-gray-100 rounded"
                  >
                    {sub.name}
                  </span>
                ))}
              </div>
            )}
          </Link>
        ))}
      </div>
    </div>
  );
}
