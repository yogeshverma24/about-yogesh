'use client'

import Breadcrumb from '@/components/Breadcrumb'

const services = [
  {
    title: 'We Design',
    description: 'The world is a visual place and the more captivating, simple and eye-catching the experience, the better. Design plays an important role in defining a brand, product or a platform. We believe design plays a larger role than being eye candy. That\'s where our team of skilled designers bring the best of visual appeal and functionality to create experiences that build your revenue and future.',
    features: [
      'Responsive Web Design',
      'User Interface Design',
      'User Experience Design',
      'Visual & Brand Design',
    ],
    imagePosition: 'left' as const,
  },
  {
    title: 'We Plan',
    description: 'The right marketing strategy will lead to success for your business. Ongoing analysis makes sure that your approaches are as fluid and evolving as the industry around you. We take the time to understand how your business can thrive. We identify the best tools to achieve targets based on your market and competition.',
    features: [
      'Brand Strategy',
      'Creative Strategy',
      'Content Strategy',
      'Digital Strategy',
    ],
    imagePosition: 'right' as const,
  },
  {
    title: 'We Analyze',
    description: 'How intelligent is your business? Is the information you\'re providing across the digital space reaching the right people and having the desired effect? This is where Data & Analytics plays an important role in optimizing your business\' performance. Our experts ensure that you\'re always top-of-mind by providing the right insights and creating strategies that pave the way to success.',
    features: [
      'Analytics',
      'Reporting',
      'Data Mining',
    ],
    imagePosition: 'left' as const,
  },
  {
    title: 'We Promote',
    description: 'By blending great ideas and technology, we ensure that you have all the ingredients to make the right noises in the market. We create differentiated go-to-market processes for your organization. We create a systematic approach – both consistent and efficient – to captivate your audience.',
    features: [
      'Online Advertising',
      'Email Marketing',
      'Social Media',
      'Search Engine Strategy',
    ],
    imagePosition: 'right' as const,
  },
  {
    title: 'We Support',
    description: 'Try not to stress. Talk with us about your online destinations and we\'ll recommend the most ideal approach to meet your objectives. As a digital agency we offer a full range of services from responsive design to SEO',
    features: [
      'Full Support',
      'Backup',
      'Hosting',
    ],
    imagePosition: 'right' as const,
  },
]

export default function WhatWeDo() {
  return (
    <div>
      <Breadcrumb
        title="What We Do"
        items={[
          { label: 'Home', href: '/' },
          { label: 'What We Do', href: '/what-we-do' },
        ]}
      />

      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="space-y-24">
            {services.map((service, index) => (
              <div
                key={index}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                  service.imagePosition === 'right' ? 'lg:grid-flow-dense' : ''
                }`}
              >
                {/* Image */}
                <div
                  className={`${
                    service.imagePosition === 'right' ? 'lg:col-start-2' : ''
                  }`}
                >
                  <div className="aspect-video rounded-lg overflow-hidden shadow-xl">
                    <div className="w-full h-full bg-gradient-to-br from-primary-main to-primary-dark flex items-center justify-center">
                      <span className="text-white text-7xl">
                        {service.title === 'We Design' && '🎨'}
                        {service.title === 'We Plan' && '📋'}
                        {service.title === 'We Analyze' && '📊'}
                        {service.title === 'We Promote' && '📢'}
                        {service.title === 'We Support' && '💼'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div
                  className={`${
                    service.imagePosition === 'right' ? 'lg:col-start-1 lg:row-start-1' : ''
                  }`}
                >
                  <h3 className="text-3xl font-bold mb-4">{service.title}</h3>
                  <p className="text-gray-700 text-lg mb-6 leading-relaxed">
                    {service.description}
                  </p>
                  <ul className="space-y-3">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center space-x-3">
                        <span className="text-primary-main">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path
                              fillRule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
