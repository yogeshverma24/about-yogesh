'use client'

import { useState } from 'react'
import Breadcrumb from '@/components/Breadcrumb'

const categories = ['All Works', 'Websites', 'Development', 'Mobile', 'Products']

const projects = [
  { id: 1, title: 'Our Project Title', category: 'development', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 2, title: 'Our Project Title', category: 'websites', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 3, title: 'Our Project Title', category: 'development', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 4, title: 'Our Project Title', category: 'websites', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 5, title: 'Our Project Title', category: 'websites', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 6, title: 'Our Project Title', category: 'development', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 7, title: 'Our Project Title', category: 'websites', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 8, title: 'Our Project Title', category: 'development', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
  { id: 9, title: 'Our Project Title', category: 'mobile', description: 'We deliver solutions that offer high levels of consistency in quality and performance in all platforms.' },
]

export default function OurWorks() {
  const [activeFilter, setActiveFilter] = useState('All Works')

  const filteredProjects =
    activeFilter === 'All Works'
      ? projects
      : projects.filter((project) => project.category === activeFilter.toLowerCase())

  return (
    <div>
      <Breadcrumb
        title="Our Works"
        items={[
          { label: 'Home', href: '/' },
          { label: 'Our Works', href: '/our-works' },
        ]}
      />

      <section className="section-padding bg-white">
        <div className="container-custom">
          {/* Filter Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                  activeFilter === category
                    ? 'bg-primary-main text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer"
              >
                <div className="aspect-video bg-gradient-to-br from-primary-main to-primary-dark flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center">
                    <span className="text-white text-5xl opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      👁️
                    </span>
                  </div>
                  <span className="text-white text-6xl">💼</span>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                  <p className="text-gray-600">{project.description}</p>
                </div>
              </div>
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No projects found in this category.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
