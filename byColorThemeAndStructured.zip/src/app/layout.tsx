import type { Metadata } from "next";
import "./globals.css";
import { ConditionalLayout } from "@/components/layout/ConditionalLayout";

export const metadata: Metadata = {
  title: "BuildMart - Hardware & Construction Marketplace | B2B & B2C",
  description:
    "India's leading B2B and B2C marketplace for hardware, pipes, water tanks, fittings, and building essentials. Bulk orders, GST invoicing, verified vendors.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased min-h-screen flex flex-col font-sans">
        <ConditionalLayout>{children}</ConditionalLayout>
      </body>
    </html>
  );
}
