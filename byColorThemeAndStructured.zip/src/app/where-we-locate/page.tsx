'use client'

import { useState } from 'react'
import Breadcrumb from '@/components/Breadcrumb'

export default function WhereWeLocate() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Simulate form submission
    setTimeout(() => {
      alert('Thank you for your message! We will get back to you soon.')
      setFormData({ name: '', email: '', message: '' })
      setIsSubmitting(false)
    }, 1000)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const contactInfo = [
    {
      icon: '📍',
      title: 'Our Address',
      details: [
        'Anugiri Appartments, 6th floor,',
        'Nagol, Hyderabad - 500003.',
      ],
    },
    {
      icon: '✉️',
      title: 'Email Address',
      details: [
        'info@catenally.com',
        'Phone: +91 888-643-2100',
      ],
    },
    {
      icon: '📞',
      title: 'Our Support',
      details: [
        'Phone: +91 888-643-2100',
        'Fax: +91 888-643-2100',
      ],
    },
  ]

  return (
    <div>
      <Breadcrumb
        title="Where We Locate"
        items={[
          { label: 'Home', href: '/' },
          { label: 'Where We Locate', href: '/where-we-locate' },
        ]}
      />

      {/* Contact Information */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {contactInfo.map((info, index) => (
              <div key={index} className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-all duration-300">
                <div className="text-5xl mb-4">{info.icon}</div>
                <h4 className="text-xl font-semibold mb-4">{info.title}</h4>
                <div className="space-y-2">
                  {info.details.map((detail, detailIndex) => (
                    <p key={detailIndex} className="text-gray-600">
                      {detail.includes('@') || detail.includes('Phone') || detail.includes('Fax') ? (
                        <a
                          href={
                            detail.includes('@')
                              ? `mailto:${detail}`
                              : detail.includes('Phone')
                              ? `tel:+918886432100`
                              : '#'
                          }
                          className="hover:text-primary-main transition-colors"
                        >
                          {detail}
                        </a>
                      ) : (
                        detail
                      )}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h6 className="text-primary-main font-semibold uppercase tracking-wide mb-2">Write a Message</h6>
              <h2 className="text-4xl md:text-5xl font-bold mb-4">Have Any Questions?</h2>
            </div>

            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl p-8 md:p-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-main focus:border-transparent transition-all"
                    placeholder="Your Name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-main focus:border-transparent transition-all"
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>
              <div className="mb-6">
                <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-main focus:border-transparent transition-all resize-none"
                  placeholder="Your Message"
                />
              </div>
              <div className="text-right">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}
