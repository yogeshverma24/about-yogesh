'use client';

import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, ShieldCheck, Truck, FileText, BarChart3, Factory, Store, Users, PackageCheck, Star, MapPin, Boxes, Search, ShoppingCart, CreditCard} from 'lucide-react';
import { colors, colorClasses } from '@/lib/constants/colors'
import { dummyCategories } from '@/lib/data/dummy';
const categories = dummyCategories.slice(0, 10);
const bgImg = '/images/hero-marketplace2.png'

export default function LandingPage() {
  return (
    <div className="w-full bg-white overflow-hidden">

      <section className="relative text-white" style={{ backgroundColor: colors.secondary[900] }} >
        <div className="absolute inset-0"
          style={{ background: 'linear-gradient(to right, rgba(0,0,0,0.6), transparent)'}}
        />

        <div className="relative max-w-7xl mx-auto px-6 py-32 grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <span
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full font-semibold text-sm"
              style={{backgroundColor: `${colors.primary[500]}1A`, color: colors.primary[400],}}
            >
              <ShieldCheck className="w-4 h-4" />
              Verified B2B & B2C Marketplace
            </span>

            <h1 className="mt-6 text-5xl xl:text-5xl font-extrabold leading-tight" style={{ color: colors.text.inverse }}>
              India’s Trusted Marketplace for{' '}
              <span style={{ color: colors.primary[500] }}>
                Hardware & Construction
              </span>{' '}
              Supplies
            </h1>

            <p className="mt-6 text-lg max-w-xl" style={{ color: colors.neutral[300] }} >
              Buy pipes, tanks, fittings, tools and construction materials directly
              from verified manufacturers, distributors and hardware shops — retail
              or bulk.
            </p>

            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                href="/products"
                className={`px-8 py-4 rounded-lg font-semibold flex items-center gap-2 text-white ${colorClasses.primary.bg} ${colorClasses.primary.hover}`}
              >
                Browse Products <ArrowRight className="w-4 h-4" />
              </Link>

              <Link
                href="/rfq"
                className="px-8 py-4 rounded-lg font-semibold border"
                style={{
                  borderColor: 'rgba(255,255,255,0.3)',
                  color: colors.text.inverse,
                }}
              >
                Request Bulk Quote
              </Link>
            </div>

            <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-8">
              <Metric icon={Users} value="50K+" label="Customers" />
              <Metric icon={Store} value="8K+" label="Vendors" />
              <Metric icon={Boxes} value="120K+" label="Products" />
              <Metric icon={MapPin} value="28+" label="States" />
            </div>
          </div>

          <div className="hidden lg:block">
            <Image src={bgImg} alt="Hardware Marketplace" width={700} height={600} className="rounded-3xl shadow-2xl" priority/>
          </div>
        </div>
      </section>

      <section className="py-28">
        <div className="max-w-7xl mx-auto px-6">
          <Header
            title="Browse Categories"
            subtitle="Everything required for construction & hardware procurement"
            action={{ label: 'View All Categories', href: '/categories' }}
          />

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-12">
            {categories.map((cat) => (
              <Link key={cat.name} href="/products" className="group flex flex-col items-center text-center">
                <div
                  className="w-40 h-40 rounded-full flex items-center justify-center shadow-lg transition"
                  style={{
                    borderWidth: 2,
                    borderStyle: 'solid',
                    borderColor: colors.neutral[300],
                    backgroundColor: colors.neutral[50],
                  }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.borderColor = colors.primary[500])
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.borderColor = colors.neutral[300])
                  }
                >
                  <Image src={cat.image} alt={cat.name} width={80} height={80} />
                </div>

                <p className="mt-4 font-semibold transition" style={{ color: colors.text.primary }}>
                  <span className="group-hover:text-[var(--primary-500)]">
                    {cat.name}
                  </span>
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-28" style={{background: `linear-gradient(135deg, ${colors.primary[50]}, ${colors.background.primary})`}}>
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-25 items-center">
          <div className="relative hidden lg:flex justify-center">
            <div className="relative w-full max-w-[640px] h-[520px]">
              <Image src="/images/why.png" alt="Why Choose Us" fill className="object-contain" priority/>
            </div>
          </div>

          <div> 
            <h2 className="text-4xl font-extrabold" style={{ color: colors.text.primary }}>
              Why Businesses Choose{' '}
              <span style={{ color: colors.primary[500] }}>Us</span>
            </h2>

            <p className="mt-4 max-w-xl" style={{ color: colors.text.secondary }} >
              Built for compliance, scale and reliability
            </p>

            <div className="mt-12 grid gap-6">
              <FeatureCard icon={ShieldCheck} title="Verified Vendors" desc="GST & KYC verified manufacturers, distributors and shops."/>
              <FeatureCard icon={Truck} title="Smart Logistics" desc="Shiprocket and multi-carrier delivery with tracking."/>
              <FeatureCard icon={FileText} title="GST Billing" desc="Auto-generated tax compliant invoices."/>
              <FeatureCard icon={BarChart3} title="Wholesale Pricing" desc="MOQ pricing and RFQ negotiation."/>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24" style={{ backgroundColor: colors.background.secondary }}>
        <div className="max-w-7xl mx-auto px-6">
          <Header title="Built for Every Buyer" subtitle="Retail simplicity with enterprise-grade power"/>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Buyer icon={Users} title="Homeowners" desc="Buy genuine materials without visiting multiple stores."/>
            <Buyer icon={PackageCheck} title="Contractors" desc="Bulk orders with site-wise delivery."/>
            <Buyer icon={Store} title="Retailers" desc="Wholesale restocking with better margins."/>
            <Buyer icon={Factory} title="Manufacturers" desc="Sell directly to B2B buyers nationwide."/>
          </div>
        </div>
      </section>

      <section className="py-28" style={{ backgroundColor: colors.background.primary }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-25 items-center">
            <div>
              <h2 className="text-4xl font-extrabold leading-tight" style={{ color: colors.text.primary }}>
                One Marketplace for <br />
                <span style={{ color: colors.primary[500] }}>Retail & Bulk</span> <br />
                Hardware Procurement
              </h2>

              <p className="mt-6 max-w-xl leading-relaxed" style={{ color: colors.text.secondary }}>
                A unified B2B & B2C platform connecting manufacturers, distributors,
                hardware stores, and buyers. From single-item purchases to large-scale
                bulk orders — procure faster, smarter, and with complete compliance.
              </p>

              <div className="mt-12 grid grid-cols-2 gap-y-10 gap-x-16">
                <div> <p className="text-3xl font-extrabold" style={{ color: colors.text.primary}} > 50K+ </p> 
                  <p className="mt-1 text-sm" style={{ color: colors.text.secondary }} >
                    Active Customers <br /> Nationwide
                  </p>
                </div>

                <div>
                  <p className="text-3xl font-extrabold" style={{ color: colors.text.primary }}> 8K+ </p>
                  <p className="mt-1 text-sm" style={{ color: colors.text.secondary }}> Verified Vendors <br /> & Manufacturers </p>
                </div>

                <div> <p className="text-3xl font-extrabold" style={{ color: colors.text.primary }}> 120K+ </p>
                  <p className="mt-1 text-sm" style={{ color: colors.text.secondary }} >
                    Hardware & Construction <br /> Products
                  </p>
                </div>

                <div>
                  <p className="text-3xl font-extrabold" style={{ color: colors.text.primary }}> 28+ </p>
                  <p className="mt-1 text-sm" style={{ color: colors.text.secondary }}>
                    States Served <br /> Across India
                  </p>
                </div>
              </div>

              <div className="mt-12">
                <Link
                  href="/products"
                  className={`inline-flex items-center gap-2 rounded-xl px-8 py-4 text-sm font-semibold text-white transition ${colorClasses.primary.bg} ${colorClasses.primary.hover}`}
                >
                  Explore Marketplace
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="relative">
              <div className="relative w-full h-[460px] rounded-[32px] overflow-hidden">
                <Image src="/images/why1.png" alt="B2B & B2C Hardware Marketplace" fill className="object-cover" priority/>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20" style={{ backgroundColor: colors.background.primary }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-3xl md:text-4xl font-extrabold" style={{ color: colors.text.primary }}>
              How the Marketplace Works
            </h2>
            <p className="mt-4 max-w-xl mx-auto" style={{ color: colors.text.secondary }} >
              Simple, fast and scalable procurement
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-14">
            <div className="text-center px-6">
              <div
                className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-6"
                style={{
                  backgroundColor: colors.primary[100],
                  color: colors.primary[500],
                }}
              >
                <Search size={32} />
              </div>
              <h4 className="text-lg font-semibold" style={{ color: colors.text.primary }}> Browse Products </h4>
              <p
                className="mt-2 text-sm leading-relaxed max-w-xs mx-auto"
                style={{ color: colors.text.secondary }}
              >
                Search by category, brand, size or rating.
              </p>
            </div>

            <div className="text-center px-6">
              <div
                className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-6"
                style={{backgroundColor: colors.primary[100], color: colors.primary[500]}}>
                <ShoppingCart size={32} />
              </div>
              <h4 className="text-lg font-semibold" style={{ color: colors.text.primary }}> Cart or RFQ </h4>
              <p className="mt-2 text-sm leading-relaxed max-w-xs mx-auto" style={{ color: colors.text.secondary }}>
                Retail checkout or request bulk quotation.
              </p>
            </div>

            <div className="text-center px-6">
              <div
                className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-6"
                style={{backgroundColor: colors.primary[100], color: colors.primary[500]}}>
                <CreditCard size={32} />
              </div>
              <h4 className="text-lg font-semibold" style={{ color: colors.text.primary }}> Pay Securely </h4>
              <p className="mt-2 text-sm leading-relaxed max-w-xs mx-auto" style={{ color: colors.text.secondary }}>
                UPI, cards, netbanking or credit.
              </p>
            </div>

            <div className="text-center px-6">
              <div
                className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-6"
                style={{backgroundColor: colors.primary[100], color: colors.primary[500]}}>
                <Truck size={32} />
              </div>
              <h4 className="text-lg font-semibold" style={{ color: colors.text.primary }}> Track Delivery </h4>
              <p className="mt-2 text-sm leading-relaxed max-w-xs mx-auto" style={{ color: colors.text.secondary }}>
                Live shipment tracking via logistics partners.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="my-10 mx-4 sm:mx-8 md:mx-12 lg:mx-20 xl:mx-50">
        <div
          className="rounded-2xl shadow-md"
          style={{borderWidth: 1, borderStyle: 'solid', borderColor: colors.primary[400], backgroundColor: `${colors.primary[500]}26`}}>
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-10 px-6 sm:px-10 py-12 md:py-16">
            <div className="flex-1 text-center md:text-left">
              <span
                className="inline-block rounded-full px-4 py-1.5 text-xs font-semibold"
                style={{ backgroundColor: colors.primary[100], color: colors.primary[600]}}>
                Start Today
              </span>

              <h2 className="mt-5 text-2xl sm:text-3xl md:text-4xl font-extrabold" style={{ color: colors.text.primary }}>
                Download the App
              </h2>

              <p className="mt-4 text-sm sm:text-base leading-relaxed max-w-xl" style={{ color: colors.text.secondary }}>
                Buy, sell and manage construction materials on the go.
                Track orders, connect with verified vendors and scale faster — anywhere.
              </p>

              <div className="mt-8 flex flex-wrap justify-center md:justify-start gap-4">
                <Link href="#" className="px-4 sm:px-5 py-3 rounded-lg flex items-center gap-4"
                  style={{ backgroundColor: colors.neutral[900], color: colors.text.inverse}}>
                  <Image src="/images/apple.png" alt="Apple" width={20} height={20} />
                  <span className="text-sm">
                    <span className="block text-xs" style={{ color: colors.neutral[300] }}> Download on the</span>
                    Apple Store
                  </span>
                </Link>

                <Link href="#" className="px-4 sm:px-5 py-3 rounded-lg flex items-center gap-4"
                  style={{ backgroundColor: colors.neutral[900], color: colors.text.inverse}}>
                  <Image src="/images/googleplay.png" alt="Google Play" width={20} height={20} />
                  <span className="text-sm">
                    <span className="block text-xs" style={{ color: colors.neutral[300] }}> Get it on</span>
                    Google Play
                  </span>
                </Link>
              </div>
            </div>

            <div className="flex-shrink-0 h-[260px] sm:h-[320px] md:h-[400px]">
              <Image src="/images/why3.png" alt="Mobile App Preview" width={320} height={520} className="h-full w-auto object-contain mx-auto"/>
            </div>
          </div>
        </div>
      </section>

      <section className="p-0">
        <div className="max-w-6xl mx-auto px-6">
          <div
            className="relative rounded-[32px] p-14 md:p-20 overflow-hidden"
            style={{
              backgroundColor: colors.background.primary,
              borderWidth: 1,
              borderStyle: 'solid',
              borderColor: colors.neutral[200],
              boxShadow: '0 30px 80px -25px rgba(0,0,0,0.15)',
            }}
          >
            <div
              className="absolute -top-24 -right-24 w-72 h-72 rounded-full blur-3xl"
              style={{ backgroundColor: `${colors.primary[100]}66` }}
            />
            <div
              className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full blur-3xl"
              style={{ backgroundColor: `${colors.primary[200]}4D` }}
            />

            <div className="relative text-center max-w-3xl mx-auto">
              <div
                className="mx-auto mb-8 w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: colors.primary[100], color: colors.primary[600],}}>
                <Star className="w-7 h-7" />
              </div>

              <h2 className="text-4xl md:text-4xl font-extrabold leading-tight" style={{ color: colors.text.primary }}>
                Ready to Buy or Sell <br className="hidden sm:block" />
                at <span style={{ color: colors.primary[600] }}>Scale</span>?
              </h2>

              <p className="mt-6 text-lg leading-relaxed" style={{ color: colors.text.secondary }}>
                Join India’s fastest growing B2B & B2C construction marketplace —
                trusted by manufacturers, vendors, contractors, and homeowners.
              </p>

              <div className="mt-12 flex flex-col sm:flex-row justify-center gap-5">
                <Link
                  href="/register?type=b2b"
                  className={`inline-flex items-center justify-center rounded-xl px-8 py-4 text-sm font-semibold text-white transition shadow-md ${colorClasses.primary.bg} ${colorClasses.primary.hover}`}
                >
                  Register as Business
                </Link>

                <Link
                  href="/vendor/register"
                  className="inline-flex items-center justify-center rounded-xl px-8 py-4 text-sm font-semibold transition"
                  style={{ borderWidth: 1, borderStyle: 'solid', borderColor: colors.neutral[300], color: colors.text.primary}}>
                  Become a Vendor
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc }: any) {
  return (
    <div className="flex gap-5 bg-white p-6 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition">
      <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 bg-orange-100`}>
        <Icon className={`w-6 h-6 ${colorClasses.primary.text}`} />
      </div>
      <div>
        <h4 className="font-semibold text-lg text-slate-900">
          {title}
        </h4>
        <p className="mt-1 text-sm text-slate-600">
          {desc}
        </p>
      </div>
    </div>
  )
}

function Header({ title, subtitle, action, light }: any) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-16">
      <div>
        <h2 className={`text-3xl md:text-4xl font-extrabold ${light ? 'text-white' : 'text-slate-900' }`}> {title} </h2>
        <p className={`mt-3 max-w-xl ${light ? 'text-slate-300' : 'text-slate-600' }`}> {subtitle} </p>
      </div>

      {action && (
        <Link href={action.href} className={`mt-6 sm:mt-0 font-semibold flex items-center gap-2 ${colorClasses.primary.text}`}>
          {action.label}
          <ArrowRight className="w-4 h-4" />
        </Link>
      )}
    </div>
  )
}

function Buyer({ icon: Icon, title, desc }: any) {
  return (
    <div className="bg-white p-8 rounded-2xl border border-gray-200 hover:shadow-xl transition">
      <Icon className={`w-10 h-10 mb-4 ${colorClasses.primary.text}`} />
      <h3 className="font-semibold text-lg text-slate-900"> {title} </h3>
      <p className="mt-2 text-sm text-slate-600"> {desc} </p>
    </div>
  )
}

function Metric({ icon: Icon, value, label }: any) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="w-6 h-6 text-orange-400" />
      <div>
        <p className="text-xl font-bold text-slate-900"> {value} </p>
        <p className="text-xs text-slate-400"> {label} </p>
      </div>
    </div>
  )
}