'use client'

import { useState } from 'react'
import Breadcrumb from '@/components/Breadcrumb'
import { colors } from '@/lib/constants/colors'

const tabs = [
  {
    id: 'mission',
    label: 'Mission',
    content: {
      description: 'The principles that motivated us guide our far-ranging creative work on behalf of our partners. We believe that the work we do must have a real impact in the online world as well as in the conventional marketplace. Be it Digital Strategy and Marketing, Websites, Mobile Applications or the Internet of Things, we blend creativity and technology to provide the best possible outcomes to take your business forward.',
      points: [
        'We combined arresting images, dynamic type, narrative design and best-in-class production in these days, to give our clients an edge.',
        'We have brand stories, balancing familiarity and surprise, message and metaphor.',
        'As an independent design company, we have always forged our own path, following several guiding lights along the way.',
      ],
    },
  },
  {
    id: 'vision',
    label: 'Vision',
    content: {
      description: 'Every project is unique, but they all start with one thing in common. We want to know everything: where you started. Where you want to go next. What you value. Who your customers are and why they care about you. The only way to solve a problem is to understand it from every angle. Luckily, we\'ve got a proven process to quench our insatiable curiosity.',
      points: [
        { title: 'Expertise', text: 'Experienced designers, developers and Marketing Experts with right tools to help you and your business.' },
        { title: 'Collaborative Approach', text: 'Together with our expertise and your opinions, we turn your ideas into reality our customers once signing a contract.' },
        { title: 'Agile', text: 'Technical excellence is measured by both capacities to deliver customer value today and create an adaptable product for tomorrow' },
        { title: 'Creative', text: 'Create content that gets noticed. Know exactly what customers want, create SEO-friendly content & ensure its easily accessible to everyone.' },
        { title: 'Strategy', text: 'With our unique strategy and collaborative approach, we ensure you and your business succeed.' },
        { title: 'Right Tools', text: 'Expertise and Strategy isn\'t enough to succeed, you must have right tools to plan and deliver with top Quality and On-time.' },
      ],
    },
  },
  {
    id: 'values',
    label: 'Values',
    content: {
      description: 'Our values are part of our DNA. They guide the way we work with our business partners, within our communities and with each other. Through Integrity, Excellence, Partnership, Approachability, Transparency and a focus on success, we have created a vibrant company culture where ideas can blossom, people can thrive and success can flourish.',
      points: [
        { title: 'Integrity', text: 'We believe in always doing the right thing, even when it hurts.' },
        { title: 'Excellence', text: 'We believe in making quality personal.' },
        { title: 'Partnership', text: 'We believe that clients are relationships, not transactions.' },
        { title: 'Approachability', text: 'We believe that every question is a good question.' },
        { title: 'Transparency', text: 'We believe in building trust through openness.' },
      ],
    },
  },
]

export default function WhoWeAre() {
  const [activeTab, setActiveTab] = useState('mission')

  const activeContent = tabs.find((tab) => tab.id === activeTab)?.content

  return (
    <div>
      <Breadcrumb
        title="Who We Are"
        items={[
          { label: 'Home', href: '/' },
          { label: 'Who We Are', href: '/who-we-are' },
        ]}
      />

      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Image */}
            <div className="order-2 lg:order-1">
              <div className="aspect-square rounded-lg overflow-hidden shadow-xl">
                <div className="w-full h-full bg-gradient-to-br from-primary-main to-primary-dark flex items-center justify-center">
                  <span className="text-white text-6xl">👥</span>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="order-1 lg:order-2">
              {/* Tab Navigation */}
              <div className="flex space-x-2 mb-6 border-b border-gray-200">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-6 py-3 font-medium transition-all duration-300 relative ${
                      activeTab === tab.id
                        ? 'text-primary-main'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    {tab.label}
                    {activeTab === tab.id && (
                      <span
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-main"
                        style={{ backgroundColor: colors.primary.main }}
                      />
                    )}
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              {activeContent && (
                <div className="space-y-6 animate-fadeIn">
                  <p className="text-gray-700 text-lg leading-relaxed">
                    {activeContent.description}
                  </p>

                  <ul className="space-y-4">
                    {activeContent.points.map((point, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <span className="text-primary-main mt-1">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path
                              fillRule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </span>
                        <div>
                          {typeof point === 'string' ? (
                            <span className="text-gray-700">{point}</span>
                          ) : (
                            <>
                              <strong className="text-gray-900">{point.title}</strong>
                              {' - '}
                              <span className="text-gray-700">{point.text}</span>
                            </>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
