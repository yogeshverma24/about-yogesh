export { colors, colorClasses } from './colors';

export const SITE_CONFIG = {
  name: 'BuildMart',
  tagline: 'Hardware & Construction Marketplace',
  description: 'B2B & B2C marketplace for pipes, tanks, fittings, and building essentials',
} as const;

export const ROUTES = {
  home: '/',
  products: '/products',
  categories: '/categories',
  cart: '/cart',
  checkout: '/checkout',
  orders: '/orders',
  rfq: '/rfq',
  vendor: {
    dashboard: '/vendor/dashboard',
    products: '/vendor/products',
    orders: '/vendor/orders',
    rfq: '/vendor/rfq',
  },
  admin: {
    dashboard: '/admin/dashboard',
    users: '/admin/users',
    vendors: '/admin/vendors',
    products: '/admin/products',
    orders: '/admin/orders',
  },
} as const;
