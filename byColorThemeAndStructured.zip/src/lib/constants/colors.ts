// theme/colors.ts

export const colors = {
  // Brand Colors
  primary: {
    50: '#fff7ed',
    100: '#ffedd5',
    200: '#fed7aa',
    300: '#fdba74',
    400: '#fb923c',
    500: '#f97316', // MAIN ORANGE (used everywhere)
    600: '#ea580c',
    700: '#c2410c',
    800: '#9a3412',
    900: '#7c2d12',
    950: '#431407',
  },

  secondary: {
    50: '#f8fafc',
    100: '#f1f5f9',
    200: '#e2e8f0',
    300: '#cbd5e1',
    400: '#94a3b8',
    500: '#64748b',
    600: '#475569',
    700: '#334155',
    800: '#1e293b',
    900: '#0f172a',
    950: '#020617',
  },

  // Neutral / Gray Scale
  neutral: {
    50: '#fafafa',
    100: '#f4f4f5',
    200: '#e4e4e7',
    300: '#d4d4d8',
    400: '#a1a1aa',
    500: '#71717a',
    600: '#52525b',
    700: '#3f3f46',
    800: '#27272a',
    900: '#18181b',
    950: '#09090b',
  },

  // Status Colors
  success: {
    light: '#dcfce7',
    DEFAULT: '#22c55e',
    dark: '#15803d',
  },

  warning: {
    light: '#fef3c7',
    DEFAULT: '#f59e0b',
    dark: '#b45309',
  },

  error: {
    light: '#fee2e2',
    DEFAULT: '#ef4444',
    dark: '#b91c1c',
  },

  info: {
    light: '#e0f2fe',
    DEFAULT: '#0ea5e9',
    dark: '#0369a1',
  },

  // Backgrounds
  background: {
    primary: '#ffffff',
    secondary: '#f8fafc',
    tertiary: '#f1f5f9',
    dark: '#0f172a',
    muted: '#f9fafb',
  },

  // Text Colors
  text: {
    primary: '#0f172a',   // slate-900
    secondary: '#475569', // slate-600
    tertiary: '#64748b',  // slate-500
    muted: '#94a3b8',     // slate-400
    inverse: '#ffffff',
    accent: '#f97316',
  },

  // Border & Divider
  border: {
    light: '#e5e7eb',
    DEFAULT: '#d1d5db',
    dark: '#94a3b8',
    accent: '#f97316',
  },

  // Shadows (semantic)
  shadow: {
    sm: 'rgba(0,0,0,0.05)',
    md: 'rgba(0,0,0,0.1)',
    lg: 'rgba(0,0,0,0.15)',
  },

  // Gradients
  gradient: {
    primary: 'linear-gradient(135deg, #f97316, #ea580c)',
    soft: 'linear-gradient(135deg, #fff7ed, #ffffff)',
    dark: 'linear-gradient(135deg, #0f172a, #020617)',
  },
} as const;

// Tailwind Utility Classes Mapping
export const colorClasses = {
  primary: {
    bg: 'bg-orange-500',
    hover: 'hover:bg-orange-600',
    text: 'text-orange-500',
    border: 'border-orange-500',
    ring: 'ring-orange-500',
  },

  secondary: {
    bg: 'bg-slate-900',
    text: 'text-slate-900',
    border: 'border-slate-900',
  },

  neutral: {
    bg: 'bg-gray-100',
    text: 'text-gray-600',
    border: 'border-gray-300',
  },

  success: {
    bg: 'bg-green-500',
    text: 'text-green-600',
    border: 'border-green-500',
  },

  warning: {
    bg: 'bg-amber-500',
    text: 'text-amber-600',
    border: 'border-amber-500',
  },

  error: {
    bg: 'bg-red-500',
    text: 'text-red-600',
    border: 'border-red-500',
  },

  info: {
    bg: 'bg-sky-500',
    text: 'text-sky-600',
    border: 'border-sky-500',
  },
} as const;
