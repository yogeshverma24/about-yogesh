import Link from 'next/link';
import { SITE_CONFIG } from '@/lib/constants';

const footerLinks = {
  customer: [
    { href: '/products', label: 'All Products' },
    { href: '/categories', label: 'Categories' },
    { href: '/rfq', label: 'Request Quote' },
    { href: '/orders', label: 'Track Order' },
  ],
  vendor: [
    { href: '/vendor/register', label: 'Sell on BuildMart' },
    { href: '/vendor/dashboard', label: 'Vendor Dashboard' },
    { href: '/vendor/products', label: 'Manage Products' },
  ],
  support: [
    { href: '/help', label: 'Help Center' },
    { href: '/faq', label: 'FAQs' },
    { href: '/contact', label: 'Contact Us' },
  ],
  legal: [
    { href: '/terms', label: 'Terms of Service' },
    { href: '/privacy', label: 'Privacy Policy' },
    { href: '/gst', label: 'GST Information' },
  ],
};

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg bg-[#2563eb] flex items-center justify-center text-white font-bold text-xl">
                B
              </div>
              <span className="font-bold text-xl text-white">{SITE_CONFIG.name}</span>
            </Link>
            <p className="mt-3 text-sm text-gray-400">{SITE_CONFIG.description}</p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Customer</h4>
            <ul className="space-y-2">
              {footerLinks.customer.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Vendors</h4>
            <ul className="space-y-2">
              {footerLinks.vendor.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Support</h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex flex-wrap gap-6 text-sm">
            {footerLinks.legal.map((link) => (
              <Link key={link.href} href={link.href} className="hover:text-white">
                {link.label}
              </Link>
            ))}
          </div>
          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} {SITE_CONFIG.name}. All rights reserved. GST Compliant.
          </p>
        </div>

        <div className="mt-6 p-4 bg-gray-800/50 rounded-lg flex flex-wrap gap-6 justify-center">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-green-500">✓</span> GST Invoicing
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-green-500">✓</span> Bulk Discounts
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-green-500">✓</span> Verified Vendors
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-green-500">✓</span> Fast Delivery
          </div>
        </div>
      </div>
    </footer>
  );
}
