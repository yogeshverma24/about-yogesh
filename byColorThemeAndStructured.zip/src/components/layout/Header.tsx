'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Search,
  ShoppingCart,
  User,
  ChevronDown,
} from 'lucide-react';
import { useCartStore } from '@/store/cart-store';
import { cn } from '@/lib/utils/cn';

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/who-we-are', label: 'Who We Are' },
  { href: '/what-we-do', label: 'What We Do' },
  { href: '/our-works', label: 'Our Works' },
  { href: '/where-we-locate', label: 'Where We Locate' },
]

export function Header() {
  const pathname = usePathname();
  const items = useCartStore((s) => s.items);
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <header className="sticky top-0 z-50 bg-white border-b">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16 gap-6">

          {/* ───── Logo ───── */}
          <Link href="/" className="text-2xl font-extrabold text-orange-500">
            Buy<span className="text-gray-900">no</span>
          </Link>

          {/* ───── Right Section ───── */}
          <div className="flex items-center gap-6">

            {/* Navigation */}
            <nav className="hidden lg:flex items-center gap-6">
              {navLinks.map((link) => {
                const active = pathname === link.href;
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      'text-sm font-semibold transition',
                      active
                        ? 'text-orange-500'
                        : 'text-gray-700 hover:text-orange-500'
                    )}
                  >
                    {link.label}
                  </Link>
                );
              })}
            </nav>

          </div>
        </div>
      </div>

      {/* ───── Mobile Search ───── */}
      <div className="md:hidden px-4 pb-3">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="search"
            placeholder="Search products..."
            className="w-full pl-11 pr-4 py-2.5 rounded-full border border-gray-300"
          />
        </div>
      </div>
    </header>
  );
}